name 'web'
description 'All Instances'
run_list 'recipe[apache2::default]'
