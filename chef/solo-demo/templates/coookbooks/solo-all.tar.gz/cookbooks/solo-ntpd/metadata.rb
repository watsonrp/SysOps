maintainer       "Kobi Biton"
maintainer_email "kobibito@amazon.lu"
license          "GPL"
description      "Installs/Configures ntpd"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.2"
