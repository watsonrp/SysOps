name             "pacman"
maintainer       "Jesse R. Adams"
maintainer_email "jesse@techno-geeks.org"
license          "Apache 2.0"
description      "Updates package list for pacman and has LWRP for pacman groups"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "1.1.1"
